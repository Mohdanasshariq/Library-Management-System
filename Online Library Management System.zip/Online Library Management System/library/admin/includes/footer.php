   <section class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   &copy; <?php echo date('Y');?> Seminar Library Website |<a href="https://amu.ac.in/" target="_blank"  > Designed by : Mohd Anas Shariq</a> 
                </div>

            </div>
        </div>
    </section>